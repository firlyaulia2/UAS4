<?php

	global $con;

	$con = mysqli_connect('localhost','root','','cruduas4A');

	if(!$con)
	{
		echo 'unable to connect with db';
		die();
	}